<div id="header-wrapper">
	<div id="header" class="container">
		<div id="menu">
			<ul>
				<li><a href="./index.php" title="Homepage">Homepage</a></li>
				<li><a href="./catalog.php" title="Catalog">Catalog</a></li>
				<li><a href="./about_us.php" title="About Us">About Us</a></li>
				<li><a href="./contact_us.php" title="Contact Us">Contact Us</a></li>
			</ul>
		</div>
	</div>
	<div id="menu2">
		<ul>
			<li><a><i class="bi bi-person-fill"></i></a></li>
			<li><a><i class="bi bi-cart-fill"></i></a></li>
		</ul>
	</div>
		<div id="logo">
			<img src="./images/logo.png">
		</div>
	</div>
</div>