<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Homepage</title>
<?php include 'header.php' ?>
<body>
<?php include 'slideshow.php' ?>
<?php include 'header-wrapper.php' ?>
<?php include 'inventory.php' ?>		
<?php include 'footer.php' ?>
<script src="./js/banner.js"></script>
</body>
</html>