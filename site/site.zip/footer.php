<div id="copyright">
	<div class="title">
		<h2>Book the Books</h2>
		<span class="byline">Phasellus nec erat sit amet nibh pellentesque congue</span> </div>
	<ul class="contact">
		<li><a href="https://twitter.com/explore" class="fa fa-twitter" target="_blank"></a></li>
		<li><a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a></li>
		<li><a href="https://www.pinterest.pt/" class="fa fa-pinterest" target="_blank"></a></li>
		<li><a href="https://www.instagram.com/?hl=pt" class="fa fa-instagram" target="_blank"></a></li>
		<li><a href="https://www.tumblr.com/?language=pt_PT" class="fa fa-tumblr" target="_blank"></a></li>
	</ul>
	<p>&copy; Myke Macedo. All rights reserved.</p>
</div>