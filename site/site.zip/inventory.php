<table id="p-table">
			<tr>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_1.jpg"/>
				<div class="p-name">O Buraco da Agulha</div>
				<div class="p-price">19,90€</div>
				<div class="p-desc">de Ken Follett</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_2.jpg"/>
				<div class="p-name">Ao Cair da Noite</div>
				<div class="p-price">17,90€</div>
				<div class="p-desc">de Judith McNaught</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_3.jpg"/>
				<div class="p-name">A Última Odisseia</div>
				<div class="p-price">18,80€</div>
				<div class="p-desc">de James Rollins</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			</tr>
			<tr>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_4.jpg"/>
				<div class="p-name">Paranoia</div>
				<div class="p-price">16,90€</div>
				<div class="p-desc">de Lisa Jackson</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_5.jpg"/>
				<div class="p-name">Sol da Meia-Noite</div>
				<div class="p-price">26,90€</div>
				<div class="p-desc">de Stephenie Meyer</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			  <td><div class="p-cell">
				<img class="p-img" src="./images/book_6.jpg"/>
				<div class="p-name">D. Filipa de Lencastre</div>
				<div class="p-price">14,90€</div>
				<div class="p-desc">de Isabel Stilwell</div>
				<button class="p-add">Add to Cart</button>
			  </div></td>
			</tr>
		  </table>