<div class="about_section">
      <h1 class="h1_about">About Us</h1>
      <p class="p_about">Sed congue, ligula eget pharetra pulvinar, orci neque aliquam elit, in blandit ex ipsum ac felis. Praesent quis augue at dui euismod posuere. Nunc urna dolor, vulputate maximus aliquet nec, pulvinar in tortor. Phasellus neque eros, maximus at odio commodo, consequat tristique enim. Sed nec elit sit amet quam egestas molestie quis at massa. Donec erat sapien, viverra sed lorem sit amet, commodo congue quam. Vivamus iaculis sagittis tortor, a dictum nisl pellentesque sed. Nullam pulvinar nisl sit amet rhoncus pharetra. Sed auctor justo quis risus fermentum fringilla. Phasellus id elit sed turpis pulvinar bibendum.</p>

    <div class="card-group">
      <div class="card" style="width: 36rem;">
        <img src="./images/jane_doe.jpg" class="img_about" alt="Jane">
        <div class="container_about">
          <h5 class="card-title">Jane Doe</h5>
          <p class="card-text">CEO & Founder</p>
          <p class="card-text">Some text that describes me lorem ipsum ipsum lorem.</p>
          <p class="card-text">jane@email.com</p>
          <button class="button_about">Contact</button></p>
        </div>
      </div>
    
      <div class="card" style="width: 36rem;">
        <img src="./images/mike_ross.jpg" class="img_about" alt="Mike">
        <div class="container_about">
          <h5 class="card-title">Mike Ross</h5>
          <p class="card-text">Art Ddirector</p>
          <p class="card-text">Some text that describes me lorem ipsum ipsum lorem.</p>
          <p class="card-text">mike@email.com</p>
          <button class="button_about">Contact</button></p>
        </div>
      </div>
      <div class="card" style="width: 36rem;">
        <img src="./images/john_doe.jpg" class="img_about" alt="John">
        <div class="container_about">
          <h5 class="card-title">John Doe</h5>
          <p class="card-text">Designer</p>
          <p class="card-text">Some text that describes me lorem ipsum ipsum lorem.</p>
          <p class="card-text">john@email.com</p>
          <button class="button_about">Contact</button></p>
        </div>
      </div>
    </div>
  </div>